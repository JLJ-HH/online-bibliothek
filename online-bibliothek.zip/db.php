<?php
// Cache-Control-Header setzen, um Browser-Caching auf allen Seiten zu verhindern (z. B. nach dem Logout)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Verbindung zur SQLite-Datenbank herstellen
try {
    $db = new PDO('sqlite:bibliothek_02.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Fremdschlüssel-Unterstützung für SQLite aktivieren
    $db->exec("PRAGMA foreign_keys = ON;");

    // 1. Tabelle für Nutzer (Erweitert um Timestamps)
    $db->exec("CREATE TABLE IF NOT EXISTS nutzer (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        adresse TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        passwort TEXT NOT NULL,
        rolle TEXT NOT NULL DEFAULT 'user',
        ist_aktiv INTEGER DEFAULT 0,
        bestaetigungstoken TEXT DEFAULT NULL,
        angelegt_am DATETIME DEFAULT CURRENT_TIMESTAMP,
        aktualisiert_am DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // 2. Tabelle für den Buchbestand (Erweitert um Timestamps)
    $db->exec("CREATE TABLE IF NOT EXISTS buecher (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titel TEXT NOT NULL,
        autor TEXT NOT NULL,
        isbn TEXT UNIQUE NOT NULL,
        bestand INTEGER NOT NULL DEFAULT 1,
        typ TEXT NOT NULL DEFAULT 'physisch',
        pdf_pfad TEXT DEFAULT NULL,
        angelegt_am DATETIME DEFAULT CURRENT_TIMESTAMP,
        aktualisiert_am DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // 3. Verknüpfungstabelle für die Ausleihen
    $db->exec("CREATE TABLE IF NOT EXISTS ausleihen (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nutzer_id INTEGER,
        buch_id INTEGER,
        ausgeliehen_am DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (nutzer_id) REFERENCES nutzer(id) ON DELETE CASCADE,
        FOREIGN KEY (buch_id) REFERENCES buecher(id) ON DELETE CASCADE
    )");

    // 4. Tabelle für KI-generierte Inhaltsverzeichnisse und Analysen (Ollama)
    $db->exec("CREATE TABLE IF NOT EXISTS buch_analysen (
        buch_id INTEGER PRIMARY KEY,
        zusammenfassung TEXT,
        inhaltsverzeichnis TEXT,
        aktualisiert_am DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (buch_id) REFERENCES buecher(id) ON DELETE CASCADE
    )");

} catch (PDOException $e) {
    die("Datenbankverbindung fehlgeschlagen: " . $e->getMessage());
}
?>